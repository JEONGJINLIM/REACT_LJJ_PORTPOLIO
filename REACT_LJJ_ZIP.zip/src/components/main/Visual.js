function Visual() {
	return <div>Visual</div>;
}

export default Visual;
