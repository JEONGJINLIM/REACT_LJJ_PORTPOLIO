function Content() {
	return <div>Content</div>;
}

export default Content;
