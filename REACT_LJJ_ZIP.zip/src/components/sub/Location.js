function Location() {
	return <div>Location</div>;
}

export default Location;
