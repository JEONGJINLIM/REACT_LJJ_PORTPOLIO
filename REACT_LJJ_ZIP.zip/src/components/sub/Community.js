function Community() {
	return <div>Community</div>;
}

export default Community;
