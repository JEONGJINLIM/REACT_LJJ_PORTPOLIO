function Department() {
	return <div>Department</div>;
}

export default Department;
