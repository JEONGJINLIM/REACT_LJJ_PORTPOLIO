import Layout from '../common/Layout';

function Members() {
	return (
		<Layout>
			<p>Members</p>
		</Layout>
	);
}

export default Members;
