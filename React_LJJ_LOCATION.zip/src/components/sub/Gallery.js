import Layout from '../common/Layout';

function Gallery() {
	return (
		<Layout>
			<p>Gallery</p>
		</Layout>
	);
}

export default Gallery;
