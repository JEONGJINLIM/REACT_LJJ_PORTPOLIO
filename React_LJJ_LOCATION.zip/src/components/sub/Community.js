import Layout from '../common/Layout';

function Community() {
	return (
		<Layout>
			<p>Communnity</p>
		</Layout>
	);
}

export default Community;
